"""Run with:  python -m pytest -q"""
import math
import random
import sys
from pathlib import Path

import networkx as nx
import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from smart_supply import demand, delay_risk, messages, routing, captain  # noqa: E402


@pytest.fixture(scope="module", autouse=True)
def run_from_root(tmp_path_factory):
    import os
    old = os.getcwd()
    os.chdir(ROOT)
    yield
    os.chdir(old)


# ---------------- Linear Regression ----------------
def test_linear_regression_by_hand_example():
    """Course example: sales 90..130 -> y = 10x + 80, MSE = 0."""
    from sklearn.linear_model import LinearRegression
    import numpy as np
    x = np.array([[1], [2], [3], [4], [5]])
    y = np.array([90, 100, 110, 120, 130])
    m = LinearRegression().fit(x, y)
    assert m.coef_[0] == pytest.approx(10)
    assert m.intercept_ == pytest.approx(80)
    assert m.predict([[8]])[0] == pytest.approx(160)


def test_demand_model_beats_baselines():
    r = demand.run(demand.load_sales(), verbose=False)
    assert r["metrics"]["MSE"] < r["baseline_week"]["MSE"]
    assert r["metrics"]["MAE"] < r["baseline_week"]["MAE"]
    assert r["metrics"]["MSE"] < r["baseline_mean"]["MSE"]
    assert r["metrics"]["R2"] > 0.8


def test_forecast_is_positive_and_has_right_length():
    r = demand.run(demand.load_sales(), verbose=False, lead_days=5)
    assert len(r["forecast"]) == 5
    assert (r["forecast"]["forecast"] > 0).all()


# ---------------- Logistic Regression ----------------
def test_no_leakage_columns_are_used():
    for col in delay_risk.LEAKY:
        assert col not in delay_risk.FEATURES


def test_logistic_beats_majority_baseline():
    r = delay_risk.run(delay_risk.load_deliveries(), verbose=False)
    assert r["metrics"]["accuracy"] > r["baseline"]["accuracy"] + 0.05
    assert r["metrics"]["roc_auc"] > 0.7


def test_sigmoid_by_hand_matches_model():
    r = delay_risk.run(delay_risk.load_deliveries(), verbose=False)
    for name, row in delay_risk.SUPPLIERS.items():
        _, _, _, p_hand = delay_risk.explain_one(r["model"], row)
        assert p_hand == pytest.approx(r["risks"][name], abs=1e-9)


# ---------------- Naive Bayes ----------------
def test_naive_bayes_beats_baseline_and_hand_math_matches():
    r = messages.run(messages.load_messages(), verbose=False)
    assert r["accuracy"] > r["baseline_accuracy"] + 0.3
    words, classes, *_, post = messages.explain_one(r["model"], messages.EXAMPLE)
    proba = r["model"].predict_proba([messages.EXAMPLE])[0]
    assert post == pytest.approx(list(proba), abs=1e-9)


@pytest.mark.parametrize("text,label", [
    ("Several bottles are broken and leaking", "Damage"),
    ("Please send the signed invoice", "Docs"),
    ("The truck is delayed by snow", "Delay"),
    ("Delivery is on schedule", "On track"),
])
def test_naive_bayes_obvious_messages(text, label):
    r = messages.run(messages.load_messages(), verbose=False)
    assert messages.classify(r["model"], text)[0] == label


# ---------------- A* ----------------
def _nx_graph(graph):
    G = nx.Graph()
    for a, nbrs in graph.items():
        for b, km in nbrs.items():
            G.add_edge(a, b, weight=km)
    return G


def test_a_star_matches_dijkstra_on_kazakhstan_map():
    graph, coords = routing.load_map()
    G = _nx_graph(graph)
    for city in graph:
        _, cost, _ = routing.a_star(graph, coords, city, routing.SHOP)
        assert cost == pytest.approx(nx.dijkstra_path_length(G, city, routing.SHOP))


def test_heuristic_is_admissible():
    graph, coords = routing.load_map()
    G = _nx_graph(graph)
    for city in graph:
        true_km = nx.dijkstra_path_length(G, city, routing.SHOP)
        assert routing.haversine_km(coords[city], coords[routing.SHOP]) <= true_km + 1e-6


def test_a_star_expands_no_more_than_dijkstra():
    graph, coords = routing.load_map()
    for v in routing.all_routes(graph, coords).values():
        assert v["km"] == pytest.approx(v["dijkstra_km"])
        assert v["expanded"] <= v["dijkstra_expanded"]


def test_a_star_on_random_graphs():
    rnd = random.Random(1103)
    for _ in range(30):
        coords = {i: (rnd.uniform(40, 55), rnd.uniform(50, 85)) for i in range(12)}
        graph = {i: {} for i in coords}
        for i in coords:
            for j in rnd.sample(list(coords), 3):
                if i != j:
                    km = routing.haversine_km(coords[i], coords[j]) * rnd.uniform(1.0, 1.6)
                    graph[i][j] = graph[j][i] = km
        G = _nx_graph(graph)
        if not nx.has_path(G, 0, 11):
            continue
        _, cost, _ = routing.a_star(graph, coords, 0, 11)
        assert cost == pytest.approx(nx.dijkstra_path_length(G, 0, 11))


def test_unreachable_goal_returns_infinity():
    coords = {"X": (45, 65), "Y": (46, 66)}
    path, cost, _ = routing.a_star({"X": {}, "Y": {}}, coords, "X", "Y")
    assert path is None and math.isinf(cost)


# ---------------- Captain (integration) ----------------
def _all():
    d = demand.run(demand.load_sales(), verbose=False)
    r = delay_risk.run(delay_risk.load_deliveries(), verbose=False)
    nb = messages.run(messages.load_messages(), verbose=False)
    graph, coords = routing.load_map()
    return d, r, nb, routing.all_routes(graph, coords)


def test_message_changes_the_decision():
    d, r, nb, routes = _all()
    calm = {"A (Shymkent)": "Truck loaded and left on time", "B (Almaty)": "Truck loaded and left on time",
            "C (Kostanay)": "Truck loaded and left on time"}
    late = dict(calm, **{"A (Shymkent)": "Our truck is stuck at the border and will be late"})
    _, best_calm = captain.decide(d, r, nb["model"], routes, calm, stock=300)
    _, best_late = captain.decide(d, r, nb["model"], routes, late, stock=300)
    assert best_calm["supplier"] == "A (Shymkent)"
    assert best_late["supplier"] != "A (Shymkent)"


def test_more_stock_means_smaller_order():
    d, r, nb, routes = _all()
    msgs = {k: "Truck loaded and left on time" for k in routes}
    small = {x["supplier"]: x["qty"] for x in captain.decide(d, r, nb["model"], routes, msgs, stock=50)[0]}
    big = {x["supplier"]: x["qty"] for x in captain.decide(d, r, nb["model"], routes, msgs, stock=5000)[0]}
    for k in small:
        assert big[k] == 0 and small[k] > 0
