"""
prepare_data.py — turn the two raw Kaggle files into small, clean files the project uses.

Run once:  python prepare_data.py
Needs (downloaded from Kaggle, NOT stored in the repo because of their size):
  data/raw/train.csv                     <- "Store Item Demand Forecasting Challenge"
  data/raw/DataCoSupplyChainDataset.csv  <- "DataCo Smart Supply Chain for Big Data Analysis"
Creates:
  data/processed/sales_item1_chain.csv   (1 826 days, item 1 summed over 10 stores)
  data/processed/deliveries.csv          (order-time features + label, no personal data)
"""
from pathlib import Path
import pandas as pd

RAW = Path("data/raw")
OUT = Path("data/processed")
OUT.mkdir(parents=True, exist_ok=True)

# ---------- 1. Daily sales of item 1 summed over all 10 stores (our shop chain) ----------
sales = pd.read_csv(RAW / "train.csv", parse_dates=["date"])
chain = sales[sales["item"] == 1].groupby("date", as_index=False)["sales"].sum()
chain.to_csv(OUT / "sales_item1_chain.csv", index=False)
print(f"sales_item1_chain.csv: {len(chain)} days, {chain['date'].min().date()} .. {chain['date'].max().date()}, "
      f"mean {chain['sales'].mean():.1f} units/day")

# ---------- 2. Deliveries: only what is known WHEN THE ORDER IS PLACED ----------
d = pd.read_csv(RAW / "DataCoSupplyChainDataset.csv", encoding="latin-1")

# Cancelled shipments never travelled, so "late or not" has no meaning for them.
d = d[d["Delivery Status"] != "Shipping canceled"]

order_date = pd.to_datetime(d["order date (DateOrders)"], format="%m/%d/%Y %H:%M")
clean = pd.DataFrame({
    "shipping_mode": d["Shipping Mode"],
    "scheduled_days": d["Days for shipment (scheduled)"],
    "payment_type": d["Type"],
    "market": d["Market"],
    "category": d["Category Name"],
    "quantity": d["Order Item Quantity"],
    "order_weekday": order_date.dt.dayofweek,
    "order_month": order_date.dt.month,
    "late": d["Late_delivery_risk"],
})
# NOT kept on purpose:
#  * "Days for shipping (real)" and "Delivery Status": known only AFTER delivery -> data leakage
#  * customer names, e-mails, passwords, streets: personal data, not needed (privacy)
clean.to_csv(OUT / "deliveries.csv", index=False)
print(f"deliveries.csv: {len(clean)} orders, late share = {clean['late'].mean():.3f}")
