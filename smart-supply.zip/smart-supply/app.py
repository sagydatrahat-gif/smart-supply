"""
Smart Supply — web interface (Gradio).

The algorithms are NOT changed here: this file only calls the same functions as main.py
and shows their results on a web page where a manager can type new data.

  Local (VS Code):  pip install -r requirements.txt   then   python app.py   -> open http://127.0.0.1:7860
  Google Colab:     see the last section of notebooks/Smart_Supply.ipynb (gives a public link)
"""
import inspect
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))
os.chdir(ROOT)  # data paths in the modules are relative to the project folder

import matplotlib  # noqa: E402
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import pandas as pd  # noqa: E402

from smart_supply import demand, delay_risk, messages, routing, captain  # noqa: E402

# ---------------------------------------------------------------------------
# 1. Train every model ONCE when the app starts (same code as main.py)
# ---------------------------------------------------------------------------
print("Smart Supply: training models on the real data (10-30 seconds)...")
SALES = demand.load_sales()
DEM = demand.run(SALES, verbose=False)
DELIVERIES = delay_risk.load_deliveries()
RISK = delay_risk.run(DELIVERIES, verbose=False)
MSGS = messages.load_messages()
NB = messages.run(MSGS, verbose=False)
GRAPH, COORDS = routing.load_map()
ROUTES = routing.all_routes(GRAPH, COORDS)
print("Smart Supply: ready.")

NAVY, LIGHT, AMBER, TEAL, MUTED = "#13202E", "#F5F5F0", "#E9A23B", "#1F6F82", "#8A96A3"
SUPPLIER_COLORS = {"A (Shymkent)": "#C0392B", "B (Almaty)": TEAL, "C (Kostanay)": "#7A5AA6"}
SUPPLIERS = list(routing.WAREHOUSES)  # ["A (Shymkent)", "B (Almaty)", "C (Kostanay)"]

SAMPLES = {
    "On time": "Truck loaded and left on time",
    "Delay": "Our truck is stuck at the border and will be late",
    "Damage": "Several milk packs arrived broken and leaking",
    "Docs": "Invoice is missing, please send the documents",
}
DEFAULT_MESSAGES = [SAMPLES["Delay"], SAMPLES["On time"], SAMPLES["Docs"]]
CLASS_COLORS = {"On track": "#2E7D4F", "Delay": "#C0392B", "Damage": "#B35A00", "Docs": "#1F6F82"}


def money(x):
    return f"{x:,.0f} ₸".replace(",", " ")


# ---------------------------------------------------------------------------
# 2. Pure functions (no Gradio inside) — easy to test, used by the page
# ---------------------------------------------------------------------------
def draw_map(highlight_paths, best_name=None, title="Delivery routes to the shop in Kyzylorda"):
    """highlight_paths: {name: list of cities}. The best route is drawn widest, in amber."""
    plt.close("all")
    fig, ax = plt.subplots(figsize=(8, 5.2))
    fig.patch.set_facecolor(LIGHT)
    ax.set_facecolor(LIGHT)
    for a, nbrs in GRAPH.items():
        for b in nbrs:
            ax.plot([COORDS[a][1], COORDS[b][1]], [COORDS[a][0], COORDS[b][0]], color="#CFC8B8", lw=2, zorder=1)
    # The best route is a wide amber band underneath; the other routes are thin lines on top,
    # so a route that shares a road with the best one (Shymkent with Almaty) stays visible.
    order = sorted(highlight_paths, key=lambda n: n != best_name)  # best drawn first (underneath)
    for name in order:
        path = highlight_paths[name]
        xs, ys = [COORDS[c][1] for c in path], [COORDS[c][0] for c in path]
        is_best = name == best_name
        ax.plot(xs, ys, color=AMBER if is_best else SUPPLIER_COLORS.get(name, TEAL),
                lw=10 if is_best else 3, zorder=2 if is_best else 3,
                solid_capstyle="round", label=f"{name}{'  ★ recommended' if is_best else ''}")
    for city, (lat, lon) in COORDS.items():
        shop = city == routing.SHOP
        ax.scatter(lon, lat, s=260 if shop else 45, marker="*" if shop else "o",
                   color=AMBER if shop else NAVY, edgecolor=NAVY, zorder=4)
        ax.annotate(city, (lon, lat), xytext=(5, 5), textcoords="offset points", fontsize=8.5, color=NAVY)
    ax.set_title(title, color=NAVY, fontsize=12, loc="left", fontweight="bold")
    ax.set_xticks([]), ax.set_yticks([])
    for s in ax.spines.values():
        s.set_visible(False)
    if highlight_paths:
        ax.legend(loc="lower left", fontsize=8.5, frameon=False)
    fig.tight_layout()
    return fig


def decision(stock, msg_a, msg_b, msg_c):
    """Main tab: the full pipeline for today's inputs."""
    try:
        stock = int(stock)
    except (TypeError, ValueError):
        return error_card("Stock must be a whole number, for example 300."), None, None, ""
    if stock < 0:
        return error_card("Stock cannot be negative. Enter 0 or more."), None, None, ""
    texts = {name: (t or "").strip() for name, t in zip(SUPPLIERS, [msg_a, msg_b, msg_c])}
    empty = [n for n, t in texts.items() if not t]
    if empty:
        return error_card(f"Type a message for {', '.join(empty)}, or press one of the example buttons."), None, None, ""

    rows, best = captain.decide(DEM, RISK, NB["model"], ROUTES, texts, stock)
    no_order = all(r["qty"] == 0 for r in rows)
    card = result_card(best, rows, stock, no_order)

    table = pd.DataFrame([{
        "": "★" if r is best and not no_order else "",
        "Supplier": r["supplier"],
        "Route, km": round(r["km"]),
        "Delivery, days": r["lead"],
        "Order, units": r["qty"],
        "P(late) model": f"{r['p_late']:.0%}",
        "Message reads as": r["msg_class"],
        "Final risk": f"{r['risk']:.0%}",
        "Transport": money(r["transport"]),
        "Expected loss": money(r["delay_cost"]),
        "Total cost": money(r["cost"]),
    } for r in rows])

    fig = draw_map({r["supplier"]: r["path"] for r in rows}, None if no_order else best["supplier"])
    return card, table, fig, explain(best, rows, stock, no_order)


def error_card(text):
    return f"<div class='ss-card ss-error'><div class='ss-big'>Check the input</div><p>{text}</p></div>"


def result_card(best, rows, stock, no_order):
    if no_order:
        return (f"<div class='ss-card'><div class='ss-eyebrow'>Today's recommendation</div>"
                f"<div class='ss-big'>No order needed today</div>"
                f"<p>{stock} units in stock cover the forecast demand until any delivery would arrive.</p>"
                f"<div class='ss-note'>AI-generated recommendation · the shop manager makes the final decision</div></div>")
    second = sorted((r for r in rows if r is not best), key=lambda r: r["cost"])[0]
    risk_cls = "bad" if best["risk"] >= 0.6 else "warn" if best["risk"] >= 0.35 else "ok"
    return (f"<div class='ss-card'><div class='ss-eyebrow'>Today's recommendation</div>"
            f"<div class='ss-big'>Order {best['qty']} units from {best['supplier']}</div>"
            f"<p class='ss-route'>{' → '.join(best['path'])} · {best['km']:.0f} km · about {best['lead']} days</p>"
            f"<div class='ss-kpis'>"
            f"<div><span>Total cost</span><b>{money(best['cost'])}</b></div>"
            f"<div><span>Risk of delay</span><b class='ss-{risk_cls}'>{best['risk']:.0%}</b></div>"
            f"<div><span>Saves vs next option</span><b>{money(second['cost'] - best['cost'])}</b></div>"
            f"</div><div class='ss-note'>AI-generated recommendation · the shop manager makes the final decision</div></div>")


def explain(best, rows, stock, no_order):
    lines = ["### How the AI reached this answer", ""]
    for r in rows:
        lines += [f"**{r['supplier']}**",
                  f"- **A\\*:** route {' → '.join(r['path'])} = {r['km']:.0f} km → delivery ⌈{r['km']:.0f}/600⌉ + 1 = {r['lead']} days",
                  f"- **Linear Regression:** demand for {r['lead']} days = {r['demand']:.0f} units, safety stock {r['safety']:.0f} "
                  f"→ order = {r['demand']:.0f} + {r['safety']:.0f} − {stock} = **{r['qty']}** units",
                  f"- **Logistic Regression:** P(late) = {r['p_late']:.0%}",
                  f"- **Naive Bayes:** “{r['message']}” → **{r['msg_class']}** (+{captain.MESSAGE_BONUS[r['msg_class']]:.0%} risk) "
                  f"→ final risk {r['risk']:.0%}",
                  f"- **Cost:** {money(r['transport'])} transport + {r['risk']:.2f} × 3 days × {r['daily']:.0f} units × 650 ₸ "
                  f"= {money(r['delay_cost'])} expected loss → **{money(r['cost'])}**", ""]
    if not no_order:
        lines.append(f"**Decision:** {best['supplier']} has the lowest total cost.")
    return "\n".join(lines)


def message_check(text):
    """Messages tab: Naive Bayes on any text, with the words that decided it."""
    text = (text or "").strip()
    if not text:
        return {}, "Type a supplier message in English, for example: *The truck broke down near Taraz*."
    words, classes, prior, like, vocab, scores, post = messages.explain_one(NB["model"], text)
    probs = {str(c): float(p) for c, p in zip(classes, post)}
    best = max(probs, key=probs.get)
    if not words:
        return probs, ("None of these words were in the training messages, so the model can only use the class "
                       "frequencies (all equal). The answer is not meaningful. Try English words like *late*, *broken*, *invoice*.")
    k = list(classes).index(best)
    rows = "\n".join(f"| {w} | " + " | ".join(f"{like[i, vocab[w]]:.4f}" for i in range(len(classes))) + " |" for w in words)
    md = (f"**Prediction: {best} ({probs[best]:.0%})**\n\n"
          f"Known words: {', '.join(words)}. Each class score = P(class) × product of P(word | class):\n\n"
          f"| word | " + " | ".join(classes) + " |\n|" + "---|" * (len(classes) + 1) + "\n" + rows +
          f"\n\nWords the model has never seen are ignored. Laplace smoothing (+1) keeps unseen word–class pairs above zero, "
          f"so one word cannot zero out a class. Score for {best}: {scores[k]:.2e}.")
    return probs, md


def risk_check(shipping_mode, payment_type, market, quantity):
    """Supplier risk tab: Logistic Regression for any supplier profile, with the z calculation."""
    row = {"shipping_mode": shipping_mode, "payment_type": payment_type, "market": market, "quantity": int(quantity)}
    b, terms, z, p = delay_risk.explain_one(RISK["model"], row)
    level = "High" if p >= 0.6 else "Medium" if p >= 0.35 else "Low"
    cls = {"High": "bad", "Medium": "warn", "Low": "ok"}[level]
    html = (f"<div class='ss-card'><div class='ss-eyebrow'>Logistic Regression</div>"
            f"<div class='ss-big'><span class='ss-{cls}'>{p:.0%}</span> chance of a late delivery</div>"
            f"<div class='ss-bar'><div style='width:{p * 100:.0f}%'></div></div>"
            f"<p>{level} risk</p></div>")
    steps = [f"z = b = {b:+.3f}"] + [f"  {w:+.3f} × {v:.3f} = {wx:+.3f}   ({n})" for n, w, v, wx in terms] + \
            [f"z = {z:+.3f}", f"P(late) = 1 / (1 + e^(−z)) = 1 / (1 + e^({-z:+.3f})) = {p:.3f}"]
    md = ("### Calculation\n```\n" + "\n".join(steps) + "\n```\n"
          "Each category becomes a 0/1 flag (one-hot), quantity is standardised, then the weighted sum z "
          "goes through the sigmoid.")
    return html, md


def demand_view(days):
    """Demand tab: Linear Regression forecast for the next N days."""
    days = int(days)
    fc = demand.forecast(DEM["full_model"], SALES["date"].max(), days)
    hist = SALES.tail(56)
    plt.close("all")
    fig, ax = plt.subplots(figsize=(8, 4))
    fig.patch.set_facecolor(LIGHT)
    ax.set_facecolor(LIGHT)
    ax.plot(hist["date"], hist["sales"], color=NAVY, lw=1.6, label="real sales (last 8 weeks)")
    ax.plot(fc["date"], fc["forecast"], color=AMBER, lw=3, marker="o", label=f"forecast, next {days} days")
    ax.set_ylabel("units per day", color=NAVY)
    ax.legend(frameon=False)
    for s in ["top", "right"]:
        ax.spines[s].set_visible(False)
    ax.set_title("Linear Regression demand forecast", color=NAVY, loc="left", fontweight="bold")
    fig.autofmt_xdate()
    fig.tight_layout()
    table = pd.DataFrame({"Date": fc["date"].dt.strftime("%a %d %b %Y"), "Forecast, units": fc["forecast"].round(0).astype(int)})
    m, bw = DEM["metrics"], DEM["baseline_week"]
    md = (f"**Total for {days} days: {fc['forecast'].sum():.0f} units.**\n\n"
          f"Test year 2017: RMSE **{m['RMSE']:.1f}** units/day (simple rule “same day last week”: {bw['RMSE']:.1f}), "
          f"MAE {m['MAE']:.1f}, R² {m['R2']:.3f}.")
    return fig, table, md


def route_view(start_city):
    """Routes tab: A* from any city to the shop, compared with Dijkstra."""
    if start_city == routing.SHOP:
        return draw_map({}, title="You are already at the shop"), None, "Pick a city other than Kyzylorda."
    path, km, trace = routing.a_star(GRAPH, COORDS, start_city, routing.SHOP)
    _, d_km, d_trace = routing.a_star(GRAPH, COORDS, start_city, routing.SHOP, use_heuristic=False)
    fig = draw_map({start_city: path}, start_city, title=f"A* route: {start_city} → {routing.SHOP}")
    table = pd.DataFrame([{"Step": i + 1, "City opened": t["node"], "g (km driven)": round(t["g"]),
                           "h (straight line left)": round(t["h"]), "f = g + h": round(t["f"])}
                          for i, t in enumerate(trace)])
    md = (f"**Route: {' → '.join(path)} = {km:.0f} km.**\n\n"
          f"Dijkstra finds the same {d_km:.0f} km {'✓' if abs(km - d_km) < 1e-6 else '✗'}, "
          f"but A* opened **{len(trace)}** cities instead of **{len(d_trace)}**, because the straight-line "
          f"estimate h pulls the search toward the shop.")
    return fig, table, md


# ---------------------------------------------------------------------------
# 3. The page
# ---------------------------------------------------------------------------
CSS = f"""
.gradio-container {{ max-width: 1280px !important; }}
.ss-header {{ background: {NAVY}; color: {LIGHT}; border-radius: 16px; padding: 28px 32px; }}
.ss-header h1 {{ color: {LIGHT}; margin: 4px 0 6px; font-size: 40px; letter-spacing: -0.5px; }}
.ss-header p {{ color: #B8C4CF; margin: 0; font-size: 16px; }}
.ss-header .ss-eyebrow {{ color: {AMBER}; }}
.ss-eyebrow {{ font-size: 12px; font-weight: 700; letter-spacing: 2.5px; text-transform: uppercase; color: {TEAL}; }}
.ss-card {{ background: {NAVY}; color: {LIGHT}; border-radius: 16px; padding: 24px 28px; border-left: 8px solid {AMBER}; }}
.ss-card p {{ color: #D6DEE5; margin: 6px 0 0; }}
.ss-card .ss-eyebrow {{ color: {AMBER}; }}
.ss-big {{ font-size: 30px; font-weight: 700; line-height: 1.15; margin-top: 6px; color: {LIGHT}; }}
.ss-route {{ font-size: 15px; }}
.ss-kpis {{ display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; margin-top: 18px; }}
.ss-kpis div {{ background: #1C2D3F; border-radius: 12px; padding: 12px 14px; }}
.ss-kpis span {{ display: block; font-size: 12px; color: #B8C4CF; text-transform: uppercase; letter-spacing: 1px; }}
.ss-kpis b {{ font-size: 22px; color: {LIGHT}; }}
.ss-ok {{ color: #6FD39A !important; }} .ss-warn {{ color: {AMBER} !important; }} .ss-bad {{ color: #FF7A6B !important; }}
.ss-note {{ margin-top: 16px; font-size: 12px; color: #B8C4CF; border-top: 1px solid #2E4256; padding-top: 10px; }}
.ss-error {{ border-left-color: #FF7A6B; }}
.ss-bar {{ height: 14px; background: #2E4256; border-radius: 8px; overflow: hidden; margin-top: 14px; }}
.ss-bar div {{ height: 100%; background: linear-gradient(90deg, {AMBER}, #FF7A6B); }}
.ss-sample button {{ min-width: 0 !important; }}
"""

HEADER = (f"<div class='ss-header'><div class='ss-eyebrow'>AI Fundamentals · Final Project · Sagydat Rahat</div>"
          f"<h1>Smart Supply</h1><p>How much to order, from which supplier, and by which road — "
          f"Linear Regression · Logistic Regression · Naive Bayes · A* search</p></div>")


def build_app(blocks_kwargs):
    import gradio as gr

    def setter(text):
        return lambda: text

    with gr.Blocks(title="Smart Supply", **blocks_kwargs) as app:
        gr.HTML(HEADER)
        with gr.Tabs():
            # ---------------- Daily decision ----------------
            with gr.Tab("Daily decision"):
                with gr.Row():
                    with gr.Column(scale=4):
                        gr.Markdown("### Today's data")
                        stock = gr.Slider(0, 1500, value=300, step=10, label="Units in stock now")
                        boxes = []
                        for name, default in zip(SUPPLIERS, DEFAULT_MESSAGES):
                            tb = gr.Textbox(value=default, label=f"Message from supplier {name}", lines=2)
                            boxes.append(tb)
                            with gr.Row(elem_classes="ss-sample"):
                                for label, text in SAMPLES.items():
                                    gr.Button(label, size="sm").click(setter(text), None, tb)
                        go = gr.Button("Calculate recommendation", variant="primary")
                    with gr.Column(scale=6):
                        card = gr.HTML()
                        table = gr.Dataframe(label="All suppliers compared", interactive=False)
                with gr.Row():
                    with gr.Column(scale=6):
                        route_map = gr.Plot(label="Routes found by A*")
                    with gr.Column(scale=5):
                        why = gr.Markdown()
                outs = [card, table, route_map, why]
                go.click(decision, [stock] + boxes, outs)
                app.load(decision, [stock] + boxes, outs)

            # ---------------- Naive Bayes ----------------
            with gr.Tab("Message check (Naive Bayes)"):
                with gr.Row():
                    with gr.Column(scale=4):
                        msg = gr.Textbox(value="The driver is stuck in traffic near Taraz", lines=3,
                                         label="Any supplier message (English)")
                        with gr.Row(elem_classes="ss-sample"):
                            for label, text in SAMPLES.items():
                                gr.Button(label, size="sm").click(setter(text), None, msg)
                        msg_go = gr.Button("Classify", variant="primary")
                    with gr.Column(scale=6):
                        msg_label = gr.Label(num_top_classes=4, label="Probability of each class")
                        msg_md = gr.Markdown()
                msg_go.click(message_check, msg, [msg_label, msg_md])
                msg.submit(message_check, msg, [msg_label, msg_md])
                app.load(message_check, msg, [msg_label, msg_md])

            # ---------------- Logistic Regression ----------------
            with gr.Tab("Supplier risk (Logistic Regression)"):
                with gr.Row():
                    with gr.Column(scale=4):
                        mode = gr.Dropdown(["Standard Class", "Second Class", "First Class", "Same Day"],
                                           value="Second Class", label="Shipping mode")
                        pay = gr.Dropdown(["DEBIT", "TRANSFER", "CASH", "PAYMENT"], value="DEBIT", label="Payment type")
                        mkt = gr.Dropdown(["Pacific Asia", "Europe", "LATAM", "USCA", "Africa"],
                                          value="Pacific Asia", label="Market")
                        qty = gr.Slider(1, 5, value=5, step=1, label="Items in the order")
                        risk_go = gr.Button("Estimate risk", variant="primary")
                    with gr.Column(scale=6):
                        risk_html = gr.HTML()
                        risk_md = gr.Markdown()
                risk_inputs = [mode, pay, mkt, qty]
                risk_go.click(risk_check, risk_inputs, [risk_html, risk_md])
                app.load(risk_check, risk_inputs, [risk_html, risk_md])

            # ---------------- Linear Regression ----------------
            with gr.Tab("Demand forecast (Linear Regression)"):
                with gr.Row():
                    with gr.Column(scale=3):
                        days = gr.Slider(1, 14, value=4, step=1, label="Days to forecast")
                        dem_go = gr.Button("Forecast", variant="primary")
                        dem_md = gr.Markdown()
                        dem_table = gr.Dataframe(interactive=False, label="Forecast")
                    with gr.Column(scale=7):
                        dem_plot = gr.Plot()
                dem_go.click(demand_view, days, [dem_plot, dem_table, dem_md])
                app.load(demand_view, days, [dem_plot, dem_table, dem_md])

            # ---------------- A* ----------------
            with gr.Tab("Route search (A*)"):
                with gr.Row():
                    with gr.Column(scale=3):
                        city = gr.Dropdown(sorted(c for c in COORDS if c != routing.SHOP), value="Kostanay",
                                           label="Start city (warehouse)")
                        route_go = gr.Button("Find route", variant="primary")
                        route_md = gr.Markdown()
                        route_table = gr.Dataframe(interactive=False, label="Order in which A* opened cities")
                    with gr.Column(scale=7):
                        route_plot = gr.Plot()
                route_go.click(route_view, city, [route_plot, route_table, route_md])
                app.load(route_view, city, [route_plot, route_table, route_md])

        gr.Markdown("<small>Data: Kaggle *Store Item Demand Forecasting*, Kaggle *DataCo Smart Supply Chain*, "
                    "160 self-written supplier messages, 16 Kazakhstan cities (road km ≈ straight line × 1.25). "
                    "Costs 220 ₸/km and 650 ₸ lost margin are assumptions.</small>")
    return app


def launch(share=None):
    """Works with old and new Gradio: in Gradio 6+ theme/css go to launch(), before that to Blocks()."""
    import gradio as gr
    theme = gr.themes.Soft(primary_hue="amber", secondary_hue="cyan", neutral_hue="slate",
                           font=[gr.themes.GoogleFont("Inter"), "Arial", "sans-serif"])
    style_in_launch = "css" in inspect.signature(gr.Blocks.launch).parameters
    app = build_app({} if style_in_launch else {"theme": theme, "css": CSS})
    if share is None:
        share = "google.colab" in sys.modules or "--share" in sys.argv
    extra = {"theme": theme, "css": CSS} if style_in_launch else {}
    app.launch(share=share, **extra)


if __name__ == "__main__":
    launch()
