# Smart Supply

**AI Fundamentals — Final Project · Sagydat Rahat (Group: 5 поток)**

A small chain of 10 shops must decide every morning **how much to order, from which supplier, and by which road**.
Smart Supply answers this with three AI topics from the course working as one pipeline:

| AI topic | Algorithm | Data | Answers |
|---|---|---|---|
| 1. Supervised learning | Linear Regression | Kaggle *Store Item Demand Forecasting* (real, 1 826 days) | How much will the shops sell? |
| 1. Supervised learning | Logistic Regression | Kaggle *DataCo Smart Supply Chain* (real, 172 765 orders) | Will this supplier be late? |
| 2. Probabilistic reasoning | Multinomial Naive Bayes | 160 supplier messages, written and labelled by the author | What does today's message mean? |
| 3. Heuristic search | A* (own implementation) | 16 real Kazakhstan cities, 18 roads | Which road is shortest? |

```
sales history ──► Linear Regression ──► demand for the delivery days ─┐
order history ──► Logistic Regression ─► P(late) per supplier ────────┤
today's message ► Naive Bayes ─────────► Delay / Damage / Docs / OK ──┼─► Captain ─► "Order N units from X by road Y"
city map ───────► A* ──────────────────► route km per supplier ───────┘
```

Every algorithm prints the same four parts: **INPUT → STEPS → OUTPUT → WHY**.

## Run it

```bash
pip install -r requirements.txt
python main.py                  # full demo, all four algorithms + decision
python main.py --quiet          # only the final decision
python main.py --stock 150      # change stock on hand
python main.py --interactive    # type today's supplier messages yourself
python -m pytest -q             # 18 tests
```

Web interface (enter new data on a page instead of in code):

```bash
python app.py                   # opens http://127.0.0.1:7860
```

In Google Colab, run the last section of the notebook (**8. Interactive web app**): it prints a public link.
Tabs: *Daily decision* (stock + three supplier messages → order, supplier, route, cost), *Message check* (Naive Bayes),
*Supplier risk* (Logistic Regression), *Demand forecast* (Linear Regression), *Route search* (A*).

Notebook version: [`notebooks/Smart_Supply.ipynb`](notebooks/Smart_Supply.ipynb) (runs in Google Colab: it clones this repo by itself).

The cleaned data is already in `data/processed/`, so the demo works right after cloning.
To rebuild it from the raw Kaggle files, put `train.csv` and `DataCoSupplyChainDataset.csv` into `data/raw/` and run `python prepare_data.py`.

## Sample input / output

Input (default): stock = 300 units, and today's messages:

```
A (Shymkent): "Our truck is stuck at the border and will be late"
B (Almaty):   "Truck loaded and left on time"
C (Kostanay): "Invoice is missing, please send the documents"
```

Output of `python main.py --quiet`:

```
supplier      km    days  demand+safety  order  P(late)  message   risk  transport  delay cost  TOTAL KZT
A (Shymkent)  543   2     326+45         72     80%      Delay     99%   119,548    314,860     434,408
B (Almaty)    1306  4     696+63         460    40%      On track  40%   287,210    135,441     422,651
C (Kostanay)  1784  4     696+63         460    40%      Docs      50%   392,458    168,498     560,956
OUTPUT : >>> ORDER 460 UNITS FROM SUPPLIER B (Almaty)
         >>> route: Almaty -> Taraz -> Shymkent -> Turkestan -> Kyzylorda (1306 km, about 4 days)
         >>> expected total cost 422,651 KZT (risk 40%)
         [AI-generated recommendation: the shop manager confirms the final order]
```

If Shymkent's message is changed to *"Truck loaded and left on time"*, Naive Bayes reads it as **On track**, the risk drops from 99 % to 80 %, and the recommendation switches to **72 units from A (Shymkent)**.
The full console output is in [`docs/sample_output.txt`](docs/sample_output.txt).

Example of one algorithm (Logistic Regression, by hand from the trained weights):

```
INPUT  : supplier A: Second Class, DEBIT, Pacific Asia, quantity 5
STEPS  : z = b = +1.296
             -0.503 * 1 = -0.503   (shipping_mode_Second Class)
             +0.331 * 1 = +0.331   (payment_type_DEBIT)
             +0.264 * 1 = +0.264   (market_Pacific Asia)
             -0.004 * 1.977 = -0.008   (quantity, standardised)
         z = +1.380 ->  P(late) = 1 / (1 + e^-1.380) = 0.799
OUTPUT : P(late) = 80 %
WHY    : a probability can be turned into an expected cost for the decision.
```

## Results (test data the models never saw)

| Algorithm | Metric | Model | Baseline |
|---|---|---|---|
| Linear Regression | RMSE / MAE / R² | **19.2 / 15.8 / 0.882** | 25.7 / 19.8 / 0.789 (same weekday last week) |
| Logistic Regression | Accuracy / Precision / ROC-AUC | **0.696 / 0.886 / 0.742** | 0.573 / 0.573 / 0.500 (always "late") |
| Naive Bayes | Accuracy / macro-F1 | **0.800 / 0.798** (5-fold CV 0.775 ± 0.062) | 0.250 (most frequent class) |
| A* | km / cities expanded (Kostanay → Kyzylorda) | **1 784 km / 6** | 1 784 km / 10 (Dijkstra) |

Testing: `tests/test_smart_supply.py` has 18 tests: models beat their baselines, no leakage columns are used,
the hand-calculated sigmoid and Naive Bayes probabilities equal the library's, A* equals Dijkstra/networkx on the
Kazakhstan map and on 30 random graphs, the heuristic is admissible, an unreachable goal is handled, and a supplier
message really changes the final decision.

## Design decisions

- **No data leakage.** DataCo's *Days for shipping (real)* and *Delivery Status* are known only after delivery, so they are excluded.
- **Privacy.** Customer names, e-mails, passwords and streets from DataCo are dropped in `prepare_data.py`.
- **Time-series split.** Demand is trained on 2013–2016 and tested on 2017, never shuffled.
- **Admissible heuristic.** Road km = straight-line km × 1.25, so the straight-line heuristic never overestimates and A* is optimal.
- **Human in the loop.** The output is a recommendation; the manager confirms the order (Kazakhstan's AI law and personal data law require that decisions are not fully automatic).

## Limitations

- Sales are one Kaggle product, not a real Kazakh shop; DataCo is global e-commerce, mapped onto our suppliers by shipping mode.
- Supplier messages are self-written (160) because no public dataset exists.
- Road distances are approximations (straight line × 1.25), not an OpenStreetMap road graph.
- Cost constants (220 ₸/km, 650 ₸ lost margin per unit, 3 delay days) are assumptions.

## Project structure

```
main.py                     console demo (argparse)
app.py                      web interface (Gradio), same models
prepare_data.py             raw Kaggle files -> clean data/processed files
src/smart_supply/
    demand.py               Linear Regression        (topic 1)
    delay_risk.py           Logistic Regression      (topic 1)
    messages.py             Naive Bayes              (topic 2)
    routing.py              A* search                (topic 3)
    captain.py              combines all results into one decision
    report.py               INPUT/STEPS/OUTPUT/WHY printing
data/processed/             clean data used by the project
notebooks/Smart_Supply.ipynb
tests/test_smart_supply.py
docs/                       AI usage, team contribution, sample output
```

## Data sources

- Store Item Demand Forecasting Challenge — https://www.kaggle.com/competitions/demand-forecasting-kernels-only
- DataCo Smart Supply Chain for Big Data Analysis — https://www.kaggle.com/datasets/shashwatwork/dataco-smart-supply-chain-for-big-data-analysis
- City coordinates: public geographic coordinates of Kazakhstan cities.

See [`docs/AI_USAGE.md`](docs/AI_USAGE.md) and [`docs/TEAM_CONTRIBUTION.md`](docs/TEAM_CONTRIBUTION.md).
