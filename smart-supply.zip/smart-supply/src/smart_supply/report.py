"""Small helpers that print every algorithm in the same 4-part format:
INPUT -> STEPS -> OUTPUT -> WHY."""

WIDTH = 78


def header(number, title):
    print()
    print("=" * WIDTH)
    print(f" [{number}] {title}")
    print("=" * WIDTH)


def part(name, lines):
    """Print one part (INPUT / STEPS / OUTPUT / WHY) with aligned indentation."""
    if isinstance(lines, str):
        lines = [lines]
    label = f"{name:<7}: "
    for i, line in enumerate(lines):
        print((label if i == 0 else " " * len(label)) + str(line))


def table(rows, headers):
    """Plain text table, no extra libraries needed."""
    rows = [[str(c) for c in r] for r in rows]
    widths = [max(len(h), *(len(r[i]) for r in rows)) for i, h in enumerate(headers)]
    line = "  ".join(h.ljust(w) for h, w in zip(headers, widths))
    out = [line, "  ".join("-" * w for w in widths)]
    out += ["  ".join(c.ljust(w) for c, w in zip(r, widths)) for r in rows]
    return out
