"""
The Captain — combines the outputs of all three AI topics into one decision.
No learning here: only transparent rules, so a manager can check every number.

For each supplier i:
  lead time      L_i   = ceil(route_km_i / 600 km per day) + 1 loading day          (A*)
  demand         D_i   = sum of forecast for the next L_i days                      (Linear Regression)
  safety stock   S_i   = 1.65 * RMSE * sqrt(L_i)   (~95 % service level)            (Linear Regression)
  order          Q_i   = max(0, D_i + S_i - stock)
  risk           R_i   = min(0.99, P(late)_i + message bonus)                       (Logistic Reg. + Naive Bayes)
  cost           C_i   = route_km_i * 220 KZT  +  R_i * 3 days * daily demand * 650 KZT lost margin
The supplier with the smallest C_i is recommended; a human manager confirms the order.
"""
import math

from . import demand
from .report import header, part, table

KM_PER_DAY = 600
TRUCK_KZT_PER_KM = 220
LOST_MARGIN_KZT = 650
DELAY_DAYS_IF_LATE = 3
MESSAGE_BONUS = {"Delay": 0.20, "Damage": 0.15, "Docs": 0.10, "On track": 0.0}


def decide(demand_result, risk_result, nb_model, routes, messages, stock):
    from .messages import classify
    rmse = demand_result["metrics"]["RMSE"]
    full = demand_result["full_model"]
    last = demand_result["test"]["date"].max()
    rows = []
    for name, route in routes.items():
        lead = math.ceil(route["km"] / KM_PER_DAY) + 1
        fc = demand.forecast(full, last, lead)["forecast"]
        d = float(fc.sum())
        safety = 1.65 * rmse * math.sqrt(lead)
        qty = max(0, math.ceil(d + safety - stock))
        p_late = risk_result["risks"][name]
        msg_class, _ = classify(nb_model, messages[name])
        risk = min(0.99, p_late + MESSAGE_BONUS[msg_class])
        daily = d / lead
        transport = route["km"] * TRUCK_KZT_PER_KM
        delay_cost = risk * DELAY_DAYS_IF_LATE * daily * LOST_MARGIN_KZT
        rows.append({"supplier": name, "km": route["km"], "lead": lead, "demand": d, "safety": safety, "qty": qty,
                     "p_late": p_late, "message": messages[name], "msg_class": msg_class, "risk": risk,
                     "daily": daily, "transport": transport, "delay_cost": delay_cost,
                     "cost": transport + delay_cost, "path": route["path"]})
    best = min(rows, key=lambda r: r["cost"])
    return rows, best


def run(demand_result, risk_result, nb_result, routes, messages, stock=300, verbose=True):
    rows, best = decide(demand_result, risk_result, nb_result["model"], routes, messages, stock)
    if not verbose:
        return rows, best
    header(5, "The Captain — one decision from all AI results")
    part("INPUT", [f"stock on hand = {stock} units; today's messages:"] +
         [f'  {r["supplier"]}: "{r["message"]}"' for r in rows])
    part("STEPS", [f"lead time = ceil(km / {KM_PER_DAY}) + 1, order = forecast(lead) + 1.65*RMSE*sqrt(lead) - stock",
                   f"risk = P(late) + message bonus {MESSAGE_BONUS}",
                   f"cost = km * {TRUCK_KZT_PER_KM} KZT + risk * {DELAY_DAYS_IF_LATE} days * daily demand * {LOST_MARGIN_KZT} KZT"] +
         table([[r["supplier"], f"{r['km']:.0f}", r["lead"], f"{r['demand']:.0f}+{r['safety']:.0f}", r["qty"],
                 f"{r['p_late']:.0%}", r["msg_class"], f"{r['risk']:.0%}", f"{r['transport']:,.0f}",
                 f"{r['delay_cost']:,.0f}", f"{r['cost']:,.0f}"] for r in rows],
               ["supplier", "km", "days", "demand+safety", "order", "P(late)", "message", "risk",
                "transport", "delay cost", "TOTAL KZT"]))
    if all(r["qty"] == 0 for r in rows):
        part("OUTPUT", [f">>> NO ORDER NEEDED TODAY: {stock} units in stock cover the demand until any delivery arrives",
                        "[AI-generated recommendation: the shop manager confirms the final order]"])
        part("WHY", "Stock on hand is larger than the forecast demand plus safety stock for every supplier.")
        return rows, best
    part("OUTPUT", [f">>> ORDER {best['qty']} UNITS FROM SUPPLIER {best['supplier']}",
                    f">>> route: {' -> '.join(best['path'])} ({best['km']:.0f} km, about {best['lead']} days)",
                    f">>> expected total cost {best['cost']:,.0f} KZT (risk {best['risk']:.0%})",
                    "[AI-generated recommendation: the shop manager confirms the final order]"])
    others = sorted((r for r in rows if r is not best), key=lambda r: r["cost"])
    part("WHY", f"{best['supplier']} has the lowest total of transport plus expected delay loss; "
                f"the next option, {others[0]['supplier']}, costs {others[0]['cost'] - best['cost']:,.0f} KZT more.")
    return rows, best
