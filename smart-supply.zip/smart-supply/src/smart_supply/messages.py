"""
AI topic 2 (Probabilistic reasoning) — Multinomial Naive Bayes for supplier messages.

Data: 160 short supplier messages written and labelled by the author (40 per class),
because no public dataset of supplier messages exists. Classes: Delay, Damage, Docs, On track.
Rule: P(C | words) is proportional to P(C) * product of P(word | C), with Laplace smoothing (alpha = 1).
Adapted from the course practice: CountVectorizer + MultinomialNB.
"""
import numpy as np
import pandas as pd
from sklearn.dummy import DummyClassifier
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics import accuracy_score, f1_score, confusion_matrix
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline

from .report import header, part, table

RANDOM_STATE = 1103
CLASSES = ["Delay", "Damage", "Docs", "On track"]
EXAMPLE = "Cargo held at customs, documents not processed yet"


def load_messages(path="data/processed/messages.csv"):
    return pd.read_csv(path)


def build_model():
    return Pipeline([("words", CountVectorizer(stop_words="english")),
                     ("nb", MultinomialNB(alpha=1.0))])


def train_and_evaluate(df):
    X_train, X_test, y_train, y_test = train_test_split(
        df["text"], df["label"], test_size=0.25, random_state=RANDOM_STATE, stratify=df["label"])
    model = build_model().fit(X_train, y_train)
    pred = model.predict(X_test)
    cv = cross_val_score(build_model(), X_train, y_train, cv=5, scoring="accuracy")
    base = DummyClassifier(strategy="most_frequent").fit(X_train, y_train)
    return {"model": model, "n_train": len(X_train), "n_test": len(X_test),
            "accuracy": accuracy_score(y_test, pred), "macro_f1": f1_score(y_test, pred, average="macro"),
            "cv_mean": cv.mean(), "cv_std": cv.std(),
            "baseline_accuracy": accuracy_score(y_test, base.predict(X_test)),
            "confusion": confusion_matrix(y_test, pred, labels=CLASSES),
            "errors": [(t, y, p) for t, y, p in zip(X_test, y_test, pred) if y != p]}


def explain_one(model, text):
    """Rebuild the probability by hand from the fitted model's own numbers."""
    vec, nb = model.named_steps["words"], model.named_steps["nb"]
    vocab = vec.vocabulary_
    words = [w for w in vec.build_analyzer()(text) if w in vocab]
    classes = list(nb.classes_)
    prior = np.exp(nb.class_log_prior_)
    like = np.exp(nb.feature_log_prob_)                       # P(word | class), already Laplace-smoothed
    scores = []
    for k, c in enumerate(classes):
        s = prior[k] * np.prod([like[k, vocab[w]] for w in words])
        scores.append(s)
    total = sum(scores)
    return words, classes, prior, like, vocab, scores, [s / total for s in scores]


def classify(model, text):
    proba = model.predict_proba([text])[0]
    k = int(np.argmax(proba))
    return model.classes_[k], dict(zip(model.classes_, proba))


def run(df, verbose=True, example=EXAMPLE):
    r = train_and_evaluate(df)
    if not verbose:
        return r
    header(3, "Naive Bayes — what does the supplier's message mean?")
    part("INPUT", [f"{len(df)} labelled supplier messages (own dataset, 40 per class): {', '.join(CLASSES)}",
                   f"train = {r['n_train']}, test = {r['n_test']} (stratified 75/25 split)",
                   f'new message: "{example}"'])
    words, classes, prior, like, vocab, scores, post = explain_one(r["model"], example)
    steps = ["1) split text into words, drop stop-words, count words per class",
             "2) P(word|C) = (count of word in C + 1) / (all words in C + vocabulary size)   <- Laplace",
             f"3) known words in the message: {words}"]
    for k, c in enumerate(classes):
        parts = " * ".join(f"{like[k, vocab[w]]:.4f}" for w in words)
        steps.append(f"   {c:<9}: P(C)={prior[k]:.3f} * {parts} = {scores[k]:.3e}")
    steps.append("4) divide each score by their sum: " + ", ".join(f"{c} {p:.1%}" for c, p in zip(classes, post)))
    part("STEPS", steps)
    cm = r["confusion"]
    out = [f"prediction: {classes[int(np.argmax(post))]}",
           f"test accuracy = {r['accuracy']:.3f}, macro-F1 = {r['macro_f1']:.3f}, "
           f"5-fold CV accuracy = {r['cv_mean']:.3f} +/- {r['cv_std']:.3f}, "
           f"baseline (most frequent class) = {r['baseline_accuracy']:.3f}",
           "confusion matrix (rows = true, columns = predicted):"]
    out += table([[c] + list(map(str, cm[i])) for i, c in enumerate(CLASSES)], ["true \\ pred"] + CLASSES)
    if r["errors"]:
        out += ["mistakes on the test set:"] + [f'  "{t}"  true={y}  predicted={p}' for t, y, p in r["errors"]]
    part("OUTPUT", out)
    part("WHY", "Supplier messages are short and labelled data is small; Naive Bayes learns from few examples, "
                "trains instantly and shows exactly which words decided the class.")
    return r
