"""
AI topic 1 (Supervised learning, regression) — Linear Regression demand forecast.

Data: Kaggle "Store Item Demand Forecasting", item 1 summed over 10 stores (2013-2017).
Model: y = b + w_t * t + sum(w_weekday * weekday dummy) + sum(w_month * month dummy)
Adapted from the course practice on LinearRegression (fit / predict / MSE).
"""
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

from .report import header, part, table

START = pd.Timestamp("2013-01-01")
WEEKDAYS = ["Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]   # Monday is the base level (dummy dropped)
MONTHS = ["Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]  # January is the base


def load_sales(path="data/processed/sales_item1_chain.csv"):
    return pd.read_csv(path, parse_dates=["date"])


def make_features(dates):
    """Turn dates into numbers a linear model can use."""
    dates = pd.to_datetime(pd.Series(dates)).reset_index(drop=True)
    X = pd.DataFrame({"t": (dates - START).dt.days})            # trend: days since start
    for i, name in enumerate(WEEKDAYS, start=1):                # weekday dummies (Mon = 0)
        X[name] = (dates.dt.dayofweek == i).astype(int)
    for i, name in enumerate(MONTHS, start=2):                  # month dummies (Jan = base)
        X[name] = (dates.dt.month == i).astype(int)
    return X


def regression_metrics(y_true, y_pred):
    mse = mean_squared_error(y_true, y_pred)
    return {"MSE": mse, "RMSE": float(np.sqrt(mse)),
            "MAE": mean_absolute_error(y_true, y_pred), "R2": r2_score(y_true, y_pred)}


def train_and_evaluate(df, split_date="2017-01-01"):
    """Train on 2013-2016, test on 2017 (time order is kept: no shuffling for time series)."""
    train, test = df[df["date"] < split_date], df[df["date"] >= split_date]
    model = LinearRegression().fit(make_features(train["date"]), train["sales"])
    pred = model.predict(make_features(test["date"]))

    # Baselines a model must beat to be useful:
    naive_week = df.set_index("date")["sales"].shift(7).loc[test["date"]].values  # same weekday last week
    mean_pred = np.full(len(test), train["sales"].mean())                          # always the average
    return {
        "model": model, "train": train, "test": test, "pred": pred,
        "metrics": regression_metrics(test["sales"], pred),
        "train_metrics": regression_metrics(train["sales"], model.predict(make_features(train["date"]))),
        "baseline_week": regression_metrics(test["sales"], naive_week),
        "baseline_mean": regression_metrics(test["sales"], mean_pred),
    }


def forecast(model, last_date, days):
    dates = pd.date_range(pd.Timestamp(last_date) + pd.Timedelta(days=1), periods=days)
    return pd.DataFrame({"date": dates, "forecast": model.predict(make_features(dates))})


def explain_one(model, date):
    """Show one prediction term by term: b + sum(w_i * x_i)."""
    x = make_features([date]).iloc[0]
    terms = [(name, w, x[name], w * x[name]) for name, w in zip(x.index, model.coef_)]
    total = model.intercept_ + sum(t[3] for t in terms)
    return x, terms, total


def run(df, verbose=True, lead_days=3):
    r = train_and_evaluate(df)
    full_model = LinearRegression().fit(make_features(df["date"]), df["sales"])  # refit on all data for the future
    fc = forecast(full_model, df["date"].max(), lead_days)
    r.update({"full_model": full_model, "forecast": fc})
    if not verbose:
        return r

    m = r["model"]
    header(1, "Linear Regression — how much will the shops sell?")
    part("INPUT", [f"{len(df)} days of real sales (Kaggle), item 1 in 10 stores, "
                   f"{df['date'].min().date()} .. {df['date'].max().date()}",
                   f"train = {len(r['train'])} days (2013-2016), test = {len(r['test'])} days (2017)",
                   "features: trend t, weekday (6 dummies), month (11 dummies) = 18 numbers per day"])
    coefs = [f"b (intercept) = {m.intercept_:8.2f}"] + [f"w_{n:<10} = {w:8.3f}" for n, w in zip(make_features([START]).columns, m.coef_)]
    day = r["test"]["date"].iloc[0]
    x, terms, total = explain_one(m, day)
    hand = [f"prediction for {day.date()} ({day.day_name()}):",
            f"  y = {m.intercept_:.2f}"] + [f"    + {w:.3f} * {v:.3f} = {wx:+.2f}   ({n})" for n, w, v, wx in terms if v != 0] + \
           [f"  y = {total:.1f} units   (real: {r['test']['sales'].iloc[0]})"]
    part("STEPS", ["1) least squares finds w and b that minimise MSE = mean((y - y_hat)^2)"] + ["   " + c for c in coefs] + ["2) " + hand[0]] + ["   " + h for h in hand[1:]])
    mt, bw, bm = r["metrics"], r["baseline_week"], r["baseline_mean"]
    rows = [["Linear Regression", f"{mt['MSE']:.1f}", f"{mt['RMSE']:.2f}", f"{mt['MAE']:.2f}", f"{mt['R2']:.3f}"],
            ["Baseline: last week", f"{bw['MSE']:.1f}", f"{bw['RMSE']:.2f}", f"{bw['MAE']:.2f}", f"{bw['R2']:.3f}"],
            ["Baseline: average", f"{bm['MSE']:.1f}", f"{bm['RMSE']:.2f}", f"{bm['MAE']:.2f}", f"{bm['R2']:.3f}"]]
    out = ["test results (2017):"] + table(rows, ["model", "MSE", "RMSE", "MAE", "R2"])
    out += [f"forecast for the next {lead_days} days: " +
            ", ".join(f"{d.date()} = {v:.0f}" for d, v in zip(fc["date"], fc["forecast"])) +
            f"  (total {fc['forecast'].sum():.0f} units)"]
    part("OUTPUT", out)
    beats = mt["MAE"] < bw["MAE"] and mt["MSE"] < bw["MSE"]
    part("WHY", f"Sales grow slowly and follow weekday and month patterns, so a straight-line model on these "
                f"features predicts demand with ~{mt['RMSE']:.0f} units error"
                + (" and beats both baselines." if beats else "; it does not beat every baseline yet."))
    return r
