"""
AI topic 1 (Supervised learning, classification) — Logistic Regression late-delivery risk.

Data: Kaggle "DataCo Smart Supply Chain", 172 765 real orders.
Only features known when the order is placed are used (no "real shipping days": that would be leakage).
Adapted from the course practice: Pipeline(scaler/encoder + LogisticRegression), train_test_split(stratify=y).
"""
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.dummy import DummyClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, precision_score, recall_score, f1_score,
                             roc_auc_score, confusion_matrix)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from .report import header, part, table

RANDOM_STATE = 1103
CATEGORICAL = ["shipping_mode", "payment_type", "market"]
NUMERIC = ["quantity"]   # scheduled_days is left out: it is fixed by shipping_mode (duplicate information)
FEATURES = CATEGORICAL + NUMERIC
LEAKY = ["Days for shipping (real)", "Delivery Status", "late"]   # must never be features

# Our three suppliers, described with the same features the model was trained on.
SUPPLIERS = {
    "A (Shymkent)": {"shipping_mode": "Second Class", "payment_type": "DEBIT",
                     "market": "Pacific Asia", "quantity": 5},
    "B (Almaty)": {"shipping_mode": "Standard Class", "payment_type": "TRANSFER",
                   "market": "Pacific Asia", "quantity": 5},
    "C (Kostanay)": {"shipping_mode": "Standard Class", "payment_type": "DEBIT",
                     "market": "Pacific Asia", "quantity": 5},
}


def load_deliveries(path="data/processed/deliveries.csv"):
    return pd.read_csv(path)


def build_model():
    pre = ColumnTransformer([
        ("cat", OneHotEncoder(handle_unknown="ignore"), CATEGORICAL),
        ("num", StandardScaler(), NUMERIC),
    ])
    return Pipeline([("prep", pre), ("model", LogisticRegression(max_iter=1000))])


def classification_metrics(y, pred, proba=None):
    out = {"accuracy": accuracy_score(y, pred), "precision": precision_score(y, pred, zero_division=0),
           "recall": recall_score(y, pred, zero_division=0), "f1": f1_score(y, pred, zero_division=0)}
    if proba is not None:
        out["roc_auc"] = roc_auc_score(y, proba)
    tn, fp, fn, tp = confusion_matrix(y, pred, labels=[0, 1]).ravel()
    out.update(tn=int(tn), fp=int(fp), fn=int(fn), tp=int(tp))
    return out


def train_and_evaluate(df):
    X, y = df[FEATURES], df["late"]
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=RANDOM_STATE, stratify=y)
    model = build_model().fit(X_train, y_train)
    proba = model.predict_proba(X_test)[:, 1]
    pred = (proba >= 0.5).astype(int)
    base = DummyClassifier(strategy="most_frequent").fit(X_train, y_train)
    return {"model": model, "n_train": len(X_train), "n_test": len(X_test),
            "metrics": classification_metrics(y_test, pred, proba),
            "train_metrics": classification_metrics(y_train, model.predict(X_train)),
            "baseline": classification_metrics(y_test, base.predict(X_test))}


def explain_one(model, row):
    """z = b + sum(w * x) over the encoded features, then P = 1 / (1 + e^-z)."""
    x = model.named_steps["prep"].transform(pd.DataFrame([row]))
    x = x.toarray()[0] if hasattr(x, "toarray") else np.asarray(x)[0]
    names = model.named_steps["prep"].get_feature_names_out()
    lr = model.named_steps["model"]
    terms = [(n.split("__")[1], w, v, w * v) for n, w, v in zip(names, lr.coef_[0], x) if abs(v) > 1e-12]
    z = lr.intercept_[0] + sum(t[3] for t in terms)
    return lr.intercept_[0], terms, z, 1 / (1 + np.exp(-z))


def supplier_risks(model):
    return {name: float(model.predict_proba(pd.DataFrame([row]))[0, 1]) for name, row in SUPPLIERS.items()}


def run(df, verbose=True):
    r = train_and_evaluate(df)
    r["risks"] = supplier_risks(r["model"])
    if not verbose:
        return r
    header(2, "Logistic Regression — will a supplier deliver late?")
    part("INPUT", [f"{len(df)} real orders (Kaggle DataCo), late share = {df['late'].mean():.1%}",
                   f"train = {r['n_train']}, test = {r['n_test']} (stratified 75/25 split)",
                   f"features known at order time: {', '.join(FEATURES)}",
                   "removed on purpose: real shipping days, delivery status (leakage); names, e-mails (privacy)"])
    name = "A (Shymkent)"
    b, terms, z, p = explain_one(r["model"], SUPPLIERS[name])
    steps = ["1) one-hot encode categories, standardise numbers, learn weights by minimising log loss",
             f"2) supplier {name}: {SUPPLIERS[name]}",
             f"   z = b = {b:+.3f}"] + [f"       {w:+.3f} * {v:+.3f} = {wx:+.3f}   ({n})" for n, w, v, wx in terms] + \
            [f"   z = {z:+.3f}",
             f"3) P(late) = 1 / (1 + e^(-z)) = 1 / (1 + e^({-z:+.3f})) = {p:.3f}"]
    part("STEPS", steps)
    m, bl = r["metrics"], r["baseline"]
    rows = [["Logistic Regression", f"{m['accuracy']:.3f}", f"{m['precision']:.3f}", f"{m['recall']:.3f}", f"{m['f1']:.3f}", f"{m['roc_auc']:.3f}"],
            ["Baseline: always 'late'", f"{bl['accuracy']:.3f}", f"{bl['precision']:.3f}", f"{bl['recall']:.3f}", f"{bl['f1']:.3f}", "0.500"]]
    out = ["test results:"] + table(rows, ["model", "accuracy", "precision", "recall", "F1", "ROC-AUC"])
    out += [f"confusion matrix: TN={m['tn']}  FP={m['fp']}  FN={m['fn']}  TP={m['tp']}",
            "late-delivery risk per supplier: " + ", ".join(f"{k} = {v:.0%}" for k, v in r["risks"].items())]
    part("OUTPUT", out)
    part("WHY", f"It gives a probability, not just yes/no, so the captain can turn risk into an expected cost; "
                f"it is right {m['accuracy']:.0%} of the time (baseline {bl['accuracy']:.0%}) and {m['precision']:.0%} "
                f"of its 'late' alarms are real. The baseline has a high F1 only because it calls every order late, "
                f"so it cannot tell suppliers apart.")
    return r
