"""
AI topic 3 (Informed / heuristic search) — A* route from a supplier warehouse to our shop.

Map: 16 real Kazakhstan cities (real coordinates) and 18 highway links.
Road length = straight-line (haversine) distance * 1.25, an approximation of road winding.
Heuristic h(n) = straight-line distance from n to the goal. Because every road is at least as long
as the straight line, h never overestimates -> A* returns the optimal route.
A* is written by hand (heapq); Dijkstra (= A* with h = 0) and networkx are used only to check it.
"""
import heapq
import math
import pandas as pd

from .report import header, part, table

ROAD_FACTOR = 1.25
SHOP = "Kyzylorda"
WAREHOUSES = {"A (Shymkent)": "Shymkent", "B (Almaty)": "Almaty", "C (Kostanay)": "Kostanay"}


def haversine_km(a, b):
    """Great-circle distance between two (lat, lon) points in km."""
    lat1, lon1, lat2, lon2 = map(math.radians, (*a, *b))
    h = math.sin((lat2 - lat1) / 2) ** 2 + math.cos(lat1) * math.cos(lat2) * math.sin((lon2 - lon1) / 2) ** 2
    return 2 * 6371 * math.asin(math.sqrt(h))


def load_map(cities="data/processed/kz_cities.csv", roads="data/processed/kz_roads.csv"):
    c = pd.read_csv(cities)
    coords = {r.city: (r.lat, r.lon) for r in c.itertuples()}
    graph = {city: {} for city in coords}
    for r in pd.read_csv(roads).itertuples():
        km = round(haversine_km(coords[r._1], coords[r.to]) * ROAD_FACTOR, 1)
        graph[r._1][r.to] = km
        graph[r.to][r._1] = km          # roads go both ways
    return graph, coords


def a_star(graph, coords, start, goal, use_heuristic=True):
    """Return (path, cost, trace). trace = list of expanded nodes with their g, h, f."""
    h = (lambda n: haversine_km(coords[n], coords[goal])) if use_heuristic else (lambda n: 0.0)
    open_heap = [(h(start), 0.0, start)]          # (f, g, node)
    g_best = {start: 0.0}
    came_from = {}
    closed = set()
    trace = []
    while open_heap:
        f, g, node = heapq.heappop(open_heap)
        if node in closed:
            continue                               # an older, worse copy of this node
        closed.add(node)
        trace.append({"node": node, "g": g, "h": f - g, "f": f})
        if node == goal:
            path = [node]
            while node in came_from:
                node = came_from[node]
                path.append(node)
            return path[::-1], g, trace
        for nxt, km in graph[node].items():
            new_g = g + km
            if nxt not in closed and new_g < g_best.get(nxt, math.inf):
                g_best[nxt] = new_g
                came_from[nxt] = node
                heapq.heappush(open_heap, (new_g + h(nxt), new_g, nxt))
    return None, math.inf, trace


def all_routes(graph, coords):
    out = {}
    for name, city in WAREHOUSES.items():
        path, cost, trace = a_star(graph, coords, city, SHOP)
        _, d_cost, d_trace = a_star(graph, coords, city, SHOP, use_heuristic=False)
        out[name] = {"path": path, "km": cost, "expanded": len(trace), "trace": trace,
                     "dijkstra_km": d_cost, "dijkstra_expanded": len(d_trace)}
    return out


def run(graph, coords, verbose=True, show_trace_for="C (Kostanay)"):
    routes = all_routes(graph, coords)
    if not verbose:
        return routes
    header(4, "A* search — which road should the truck take?")
    n_roads = sum(len(v) for v in graph.values()) // 2
    part("INPUT", [f"map of {len(graph)} Kazakhstan cities, {n_roads} roads (km = straight line * {ROAD_FACTOR})",
                   f"goal: our shop in {SHOP}; starts: " + ", ".join(f"{k} -> {v}" for k, v in WAREHOUSES.items())])
    r = routes[show_trace_for]
    rows = [[i + 1, t["node"], f"{t['g']:.0f}", f"{t['h']:.0f}", f"{t['f']:.0f}"] for i, t in enumerate(r["trace"])]
    steps = ["f(n) = g(n) + h(n); g = km driven so far, h = straight-line km left to " + SHOP,
             "always expand the open city with the smallest f; stop when the goal is expanded",
             f"expansion order for {show_trace_for}:"] + ["  " + l for l in table(rows, ["step", "city", "g", "h", "f"])]
    part("STEPS", steps)
    rows = [[k, " -> ".join(v["path"]), f"{v['km']:.0f}", v["expanded"], f"{v['dijkstra_km']:.0f}", v["dijkstra_expanded"]]
            for k, v in routes.items()]
    part("OUTPUT", table(rows, ["supplier", "A* route", "km", "A* expanded", "Dijkstra km", "Dijkstra expanded"]))
    part("WHY", "A* finds the same optimal route as Dijkstra (same km) but expands fewer cities, because the "
                "straight-line heuristic points the search toward the shop.")
    return routes
