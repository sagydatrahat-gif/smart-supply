"""
Smart Supply — console demo.

  python main.py                    run everything with the default messages
  python main.py --stock 150        change the stock on hand
  python main.py --interactive      type today's supplier messages yourself
  python main.py --quiet            print only the final decision
"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent / "src"))

from smart_supply import demand, delay_risk, messages, routing, captain  # noqa: E402

DEFAULT_MESSAGES = {
    "A (Shymkent)": "Our truck is stuck at the border and will be late",
    "B (Almaty)": "Truck loaded and left on time",
    "C (Kostanay)": "Invoice is missing, please send the documents",
}


def main():
    ap = argparse.ArgumentParser(description="Smart Supply: what to order, from whom, by which road")
    ap.add_argument("--stock", type=int, default=300, help="units of the product left in stock (default 300)")
    ap.add_argument("--interactive", action="store_true", help="type today's supplier messages")
    ap.add_argument("--quiet", action="store_true", help="print only the final decision")
    args = ap.parse_args()
    if args.stock < 0:
        ap.error("--stock must be 0 or more")

    msgs = dict(DEFAULT_MESSAGES)
    if args.interactive:
        print("Type today's message from each supplier (press Enter to keep the default).")
        for name, default in msgs.items():
            text = input(f"  {name} [{default}]: ").strip()
            if text:
                msgs[name] = text

    verbose = not args.quiet
    print("SMART SUPPLY — AI Fundamentals final project · Sagydat Rahat")
    d = demand.run(demand.load_sales(), verbose=verbose)
    r = delay_risk.run(delay_risk.load_deliveries(), verbose=verbose)
    nb = messages.run(messages.load_messages(), verbose=verbose)
    graph, coords = routing.load_map()
    routes = routing.run(graph, coords, verbose=verbose)
    captain.run(d, r, nb, routes, msgs, stock=args.stock, verbose=True)


if __name__ == "__main__":
    main()
