# AI Usage Declaration

**Student:** Sagydat Rahat · **Project:** Smart Supply · **Course:** AI Fundamentals

**AI tool used:** Claude (Anthropic), as a programming and writing assistant.

## What the AI helped with
| Part | AI contribution | My contribution |
|---|---|---|
| Project idea | Suggested combining four algorithms into one supply decision | Chose the problem (shop supply in Kazakhstan) and approved the design |
| Data | Wrote `prepare_data.py` (cleaning, leakage and privacy checks); drafted the 160 supplier messages | Found and downloaded both Kaggle datasets; checked the message labels |
| Code | Drafted the modules in `src/smart_supply/`, `main.py` and the tests, in the style of the course practices (scikit-learn `Pipeline`, `train_test_split`, `LinearRegression`, `LogisticRegression`, `MultinomialNB`) | Ran the code, checked the outputs, changed parameters, and can explain every function |
| A* | Drafted the `heapq` implementation and the Kazakhstan city graph | Traced the algorithm by hand (see the STEPS table) and checked it against Dijkstra |
| Documentation | Drafted README, notebook text and this declaration | Reviewed and edited them |

## How AI-assisted code is explained
- Every algorithm prints **INPUT → STEPS → OUTPUT → WHY**, and the STEPS rebuild the result by hand
  (linear terms `w·x`, the sigmoid, Naive Bayes products, the A* `f = g + h` table).
- Tests check that the hand calculation equals the library result.
- I can explain each step during the defense.

## What was not done with AI
- No AI-generated data is presented as real: the Kaggle data is real; the supplier messages are clearly marked as self-written.
- The final decision in the program is a recommendation; a human confirms it.
