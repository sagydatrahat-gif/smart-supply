# Team Contribution Statement

**Team:** individual project

| Member | Contribution | Share |
|---|---|---|
| Sagydat Rahat | Problem choice, data collection (Kaggle), running and checking all models, testing, notebook, presentation, demo video, defense | 100 % |

If the project is done in a team, list every member here with their tasks; every member must be able to explain all four algorithms.
